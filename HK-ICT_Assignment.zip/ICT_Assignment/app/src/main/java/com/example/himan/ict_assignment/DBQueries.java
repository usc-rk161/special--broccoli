package com.example.himan.ict_assignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBQueries extends SQLiteOpenHelper {
    Context mContext;
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME ="records.db";
    private String TABLE_NAME = "reciepts";

    public static final String Col_1 = "Id";
    public static final String Col_2 = "Title";
    public static final String Col_3  = "Place";
    public static final String Col_4 = "Details";

    public DBQueries(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_RECORD_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + Col_1 + " TEXT,"+ Col_2 + " TEXT,"+ Col_3 + " TEXT,"+ Col_4 + " TEXT)";
        sqLiteDatabase.execSQL(CREATE_RECORD_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    void displayEntries(DataSaveDisplay saveDisplay) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Col_1, saveDisplay.getid());
        values.put(Col_2, saveDisplay.gettitle());
        values.put(Col_3, saveDisplay.getplace());
        values.put(Col_4, saveDisplay.getdetails());
    }
}
