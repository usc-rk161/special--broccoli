package com.example.himan.ict_assignment;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RecordEntry extends AppCompatActivity {
    EditText et_title, et_place, et_details, et_id;
    Button bt_date, bt_location, bt_image, bt_share, bt_save, bt_reset, bt_help, bt_show;
    TextView tv_disLocation;
    ImageView iv_imagePreview;
    DBQueries SQLITEHELPER;

    Date date = new Date();
    GPSTracker gps;
    private static final int CAMERA_PIC_REQUEST = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_entry);
        et_title = (EditText)findViewById(R.id.et_title);
        et_id = (EditText)findViewById(R.id.et_id);
        et_place = (EditText)findViewById(R.id.et_place);
        et_details = (EditText)findViewById(R.id.et_details);
        tv_disLocation = (TextView)findViewById(R.id.tv_disLocation);
        bt_date = (Button)findViewById(R.id.bt_date);
        bt_location = (Button)findViewById(R.id.bt_location);
        bt_image = (Button)findViewById(R.id.bt_image);
        bt_share = (Button)findViewById(R.id.bt_share);
        bt_save = (Button)findViewById(R.id.bt_save);
        bt_reset = (Button)findViewById(R.id.bt_reset);
        bt_show = (Button)findViewById(R.id.bt_show);
        iv_imagePreview = (ImageView) findViewById(R.id.iv_imagePreview);

        bt_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                bt_date.setText(dateFormat.format(date));
            }
        });
        bt_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gps = new GPSTracker(RecordEntry.this);
                if(gps.canGetLocation()){
                    double latitude = gps.getLatitude();
                    double longitude = gps.getLongitude();
                    tv_disLocation.setText("lat :"+ latitude + " & " + "long :"+ longitude);
                }else{
                    gps.showSettingsAlert();
                }
            }
        });

        bt_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent share = new Intent(android.content.Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "et_title");
                startActivity(Intent.createChooser(share, "Share link!"));
            }
        });
        bt_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_id.setText("");
                et_title.setText("");
                et_place.setText("");
                et_details.setText("");
                tv_disLocation.setText("");
                iv_imagePreview.setImageBitmap(null);
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBQueries dh =new DBQueries(getApplicationContext());
                SQLiteDatabase db = dh.getWritableDatabase();
                String id = et_id.getText().toString();
                String title = et_title.getText().toString();
                String place = et_place.getText().toString();
                String details = et_details.getText().toString();
                ContentValues cv = new ContentValues();
                cv.put("ID", id);
                cv.put("Title", title);
                cv.put("Place", place);
                cv.put("Details", details);
                db.insert("totalrecords", null, cv);
                Toast.makeText(getApplicationContext(),"Successfully inserted" , Toast.LENGTH_SHORT).show();
            }
        });
        bt_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RecordHistory.class);
                startActivity(intent);
            }
        });



        bt_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
            }
        });

    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_PIC_REQUEST) {
            Bitmap image = (Bitmap) data.getExtras().get("data");
            iv_imagePreview.setImageBitmap(image);
        }
    }


}