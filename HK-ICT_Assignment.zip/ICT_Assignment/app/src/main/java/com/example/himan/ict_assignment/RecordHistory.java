package com.example.himan.ict_assignment;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class RecordHistory extends AppCompatActivity {
    EditText et_id;
    Button bt_show;
    TextView tv_title, tv_place, tv_details;
    private DBQueries dbQueries;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_history);

        tv_title = (TextView)findViewById(R.id.tv_title);
        tv_place = (TextView)findViewById(R.id.tv_place);
        tv_details = (TextView)findViewById(R.id.tv_details);
        et_id = (EditText)findViewById(R.id.et_id);
        bt_show = (Button)findViewById( R.id.bt_show);
        bt_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = et_id.getText().toString();
                DBQueries dbQueries = new DBQueries(getApplicationContext());
                SQLiteDatabase sqLiteDatabase = dbQueries.getReadableDatabase();
                String abc = "Select * from reciepts where id=?";
                Cursor cursor = sqLiteDatabase.rawQuery(abc, new String[]{id});
                if(cursor.moveToFirst()){
                    tv_title.setText(cursor.getString(0));
                    tv_place.setText(cursor.getString(1));
                    tv_details.setText(cursor.getString(3));
                }else{
                    Toast.makeText(RecordHistory.this,"Not found" , Toast.LENGTH_SHORT).show();
                }

            }
        });



    }





}
