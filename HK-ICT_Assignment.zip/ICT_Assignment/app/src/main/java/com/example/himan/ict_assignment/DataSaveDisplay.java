package com.example.himan.ict_assignment;

public class DataSaveDisplay {
    String id, title, place, details;

    public String getid() {
        return id;
    }
    public String gettitle() {
        return title;
    }
    public String getplace() {
        return place;
    }
    public String getdetails() {
        return details;
    }

    public void setid(String id) {
        this.id = id;
    }
    public void settitle(String title) {
        this.title = title;
    }
    public void setdetails(String details) {
        this.details = details;
    }
    public void setplace(String place) {
        this.place = place;
    }

    public DataSaveDisplay(String id, String title, String details, String place) {

        this.id = id;
        this.title = title;
        this.details = details;
        this.place = place;

    }

}
